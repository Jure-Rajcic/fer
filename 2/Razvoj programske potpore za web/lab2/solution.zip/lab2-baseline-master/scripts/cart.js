function getCart() {
    //INSERT CODE HERE - Zadatak
    if (localStorage.cart == null) return null
    let cart = new Map(JSON.parse(localStorage.cart));
    let retval = new Map()
    for (let [key, value] of cart.entries()) {
        retval.set(key, value)
    }
    //console.log(retval)
    return cart;
    //END INSERT CODE - Zadatak
}

let refreshCart = async function () {
    let map = getCart();
    if (map) {
        if (map.size < 1) return;
        let container = document.querySelector('.cart');
        container.innerHTML = "";

        let cartHeaderTemplate = document.querySelector('#cart-template-header');
        let cartHeader = cartHeaderTemplate.content.cloneNode(true);
        container.appendChild(cartHeader);

        //INSERT CODE HERE - Zadatak
        let response = await fetch("data/lab2.json");

        let promoCodeText = document.querySelector('#promo-code-text');
        let promoCodeStatus = document.querySelector('#promo-code-status');
        let promoCodeButton = document.querySelector('#promo-code-button');
        promoCodeButton.onclick = (event) => {
            //console.log(promoCodeText.value)
            let inputText = promoCodeText.value;
            localStorage.promoCode = inputText;
            //let cartItemTemplate = document.querySelector('#cart-template-item');
            //let cartItem = cartItemTemplate.content.cloneNode(true);

            if (inputText == "WEBLAB2") {
                promoCodeStatus.textContent = "20% Discount applied. Enjoy!"
            } else {
                promoCodeStatus.textContent = "Discount not applied."
            }
            let items = document.querySelectorAll('.cart-item');

            for (let i = 0; i < items.length; i++) {
                let item = items[i];
                //console.log(item.getAttribute("data-id"))
                let priceDiv = item.querySelector('.cart-item-price')
                let product = data.products.find(p => p.id == item.getAttribute("data-id"));
                if(inputText == "WEBLAB2"){
                    priceDiv.textContent = (product.price * 0.8) + " kn";
                } else {
                    priceDiv.textContent = product.price + " kn";
                }
                
            }


            //console.log(items)



        }
        //END INSERT CODE - Zadatak
        let data = await response.json();

        let cartItemTemplate = document.querySelector('#cart-template-item');
        for (const id of map.keys()) {
            let product = data.products.find(p => p.id == id);
            let cartItem = cartItemTemplate.content.cloneNode(true);

            cartItem.querySelector(".cart-item").dataset.id = id;
            let title = cartItem.querySelector('.cart-item-title');
            title.textContent = product.name;
            let quantity = cartItem.querySelector('.cart-item-quantity');
            quantity.value = map.get(product.id);

            let price = cartItem.querySelector('.cart-item-price');
            //price.textContent = product.price + " kn";
            let promoCodeStatus = document.querySelector("#promo-code-status");
            //INSERT CODE HERE - Zadatak
            if (localStorage.promoCode == "WEBLAB2") {
                price.textContent = (product.price * 0.8) + " kn";
                promoCodeStatus.textContent = "20% Discount applied. Enjoy!"
            } else {
                price.textContent = product.price + " kn";
                promoCodeStatus.textContent = "Discount not applied."
            }

            //END INSERT CODE - Zadatak

            container.appendChild(cartItem);
        }
    }
}

refreshCart();