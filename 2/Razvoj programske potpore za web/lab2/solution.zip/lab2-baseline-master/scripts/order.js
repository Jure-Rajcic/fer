function addToCart(id) {
	// INSERT CODE HERE --> PRIPREMA
	
	if(localStorage.cart == null) {
		localStorage.cart = JSON.stringify([]);
	} 
	cart = new Map(JSON.parse(localStorage.cart));
	if (cart.get(id) == null) {
		cart.set(id, 1);
	} else {
		cart.set(id, Number(cart.get(id)) + 1);
	}
	localStorage.cart = JSON.stringify(Array.from(cart.entries()));

	let currentState = localStorage.getItem("count");
	if (currentState == null) {
		localStorage.setItem("count", 1);
	} else {
		localStorage.setItem("count", Number(localStorage.getItem("count")) + 1);
	}

	// END INSERT --> PRIPREMA
	refreshCartItems();
}

let getData = async function () {
	let response = await fetch("data/lab2.json");
	let data = await response.json();
	addCategories(data);
}

let addCategories = async function (data) {
	let categories = data.categories;
	let main = document.querySelector('main');
	let categoryTemplate = document.querySelector('#category-template');
	//console.log(categoryTemplate);
	for (let index = 0; index < categories.length; index++) {
		let category = categoryTemplate.content.cloneNode(true);
		let categoryTitleElement = category.querySelector('.decorated-title > span');
		categoryTitleElement.textContent = categories[index].name;
		let products = data.products.filter(p => p.categoryId == categories[index].id);

		// INSERT CODE HERE --> PRIPREMA
		let gallery = category.querySelector('.gallery');
		let productTemplate = document.querySelector('#product-template');

		
		let filterButtun = document.querySelector('.order-filter-apply');
		filterButtun.onclick = (event) => {

			let inputText = document.querySelector('.order-filter-input').value;
			let items = document.querySelectorAll('.photo-box');
			for(let i = 0; i < items.length; i++){
				//console.log(items[i])
				let title = items[i].querySelector('.photo-box-title').textContent;
				if(title.toLowerCase().includes(inputText.toLowerCase())) {
					items[i].style.display = "initial"
					console.log(title + " prezivija ")
				} else {
					console.log(items[i])
					items[i].style.display = "none"
					console.log(title + " nije prezivija ")
				}
			}
		}

		
		for (let i = 0; i < products.length; i++) {
			let product = productTemplate.content.cloneNode(true);
			let productImgElement = product.querySelector('.photo-box-image');
			productImgElement.src = products[i].imageUrl;
			let productTitleElement = product.querySelector('.photo-box-title');
			productTitleElement.textContent = products[i].name;
			let fotoBox = product.querySelector('.photo-box');
			fotoBox.setAttribute('data-id', products[i].id);
			let cartBtn = product.querySelector('.cart-btn');
			cartBtn.onclick = (event) => addToCart(products[i].id);
			gallery.appendChild(product);
			
		}



		// END INSERT --> PRIPREMA

		main.appendChild(category);
	}
};
getData();