function refreshCartItems(){
	// INSERT CODE HERE --> PRIPREMA
	
	let numberOfItems = document.querySelector("#cart-items");
	let currentState = localStorage.getItem("count");
	if(currentState == null){
		numberOfItems.textContent = "0";
		return;
	}
	numberOfItems.textContent = currentState

	// END INSERT --> PRIPREMA
}

//localStorage.clear();
refreshCartItems();