// potrebno napisati
var express = require('express');
var router = express.Router();

// view home
//      model : {title : 'Home'}

router.get('/', function(req, res, next) {
    res.render('../views/home', {
        title: 'Home',
        linkActive: 'home'
    });
});

module.exports = router;