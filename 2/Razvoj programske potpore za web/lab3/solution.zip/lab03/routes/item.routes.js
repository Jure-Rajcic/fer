// potrebno nadopunit
var express = require('express');
const { type } = require('express/lib/response');
var router = express.Router();
const db = require('../db');

let getProducts = async function () {
    return (await db.query('select inventory.id, imageurl, inventory.name , price, colors, categories.name ' +
    'as category_name,  description, seasonal from inventory  join categories on categoryid = categories.id')).rows;
}

let getProduct = async function (req, res, next) {
    let id = parseInt(req.params.item); // moras uzeti int
    let products = ( await getProducts()).filter(e => e.id == id)
    return products[0];
}


router.get('/:item([1-9]|10)/addExpert', async (req, res, next) => {
    res.render('../views/addExpert', {
        title: 'Add Expert',
        linkActive: 'order',
        product: await getProduct(req, res, next)
    });
});


// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// osiguravamo da je item/[broj od 1 do 99] '/:item([0-9]{1,2})/addExpert'
router.get('/:item([1-9]|10)$/', async (req, res, next) => {
    let product = await getProduct(req, res, next); // because id is unique
    res.render('../views/item', {
        title: product.name,
        linkActive: 'order',
        product: product,
        experts: (await db.query(`select * from experts where expertfor = ${req.params.item};`)).rows,
        partners: (await db.query(`select * from partners where partnerfor = ${req.params.item};`)).rows
    });
});



const emailRegexp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
const nameRegexp = /^.{3,20}$/
const checkYear = function(s, y_min, y_max){ return parseInt(s) >= y_min && parseInt(s) <= y_max;}

router.post('/:item([1-9]|10)/addExpert', async function(req, res, next) {
    let expert = req.body;
    let id = parseInt(req.params.item);
    let errors = [];

    if(!nameRegexp.test(expert.name.trim())){ errors.push({msg: 'Invalid value', param:'name'})}
    if(!nameRegexp.test(expert.surname.trim())) { errors.push({msg: 'Invalid value', param:'surname'})}
    if(!emailRegexp.test(expert.email.trim())){ errors.push({msg: 'Invalid value', param:'email'})}
    if(!checkYear(expert.employedsince, 1970, 2021)){ errors.push({msg: 'Invalid value', param:'employedsince'})}
    if(!checkYear(expert.expertsince, 1970, 2021)){ errors.push({msg: 'Invalid value', param:'expertsince'})}

    if(errors.length == 0){
        let values = `'${expert.name.trim()}', '${expert.surname.trim()}', '${expert.email.trim()}', ${expert.employedsince}, ${expert.expertsince}, ${id}`;
        let string = `insert into experts (name, surname, email, employedsince, expertsince, expertfor) values(${values});`;
        //let string = `insert into experts2 (name, surname, email, employedsince, expertsince, expertfor) values(${values});`; // testiranje ako neradi
        try{
            await db.query(string);
            res.redirect(('../' + id))
        } catch (err) {
            res.render('../views/errors', {
                title: "Error Add Expert",
                linkActive: 'order',
                errors: 'none',
                errDB: err.message,
                itemID: id
            });
        }
    } else {
        res.render('../views/errors', {
            title: "Error Add Expert",
            linkActive: '',
            errors: errors,
            errDB: undefined,
            itemID: id
        });
    }
})

// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// mora bit /:___ -> to je key u req.params
router.get('/:item([1-9]|10)/:editExpert/:id([1-9]|10)$/', async function(req, res, next) {
    res.render('../views/editExpert', {
        title: 'Edit Expert',
        linkActive: 'order',
        expert: (await db.query(`select * from experts where id = ${req.params.id};`)).rows[0],
        product: await getProduct(req, res, next)
    });
});


const nameRegexp2 = /^.{4,25}$/

router.post('/:item([1-9]|10)/:editExpert/:id([1-9]|10)$/', async function(req, res, next) {
    let expert = req.body;
    let id = parseInt(req.params.item);
    let errors = [];

    if(!nameRegexp2.test(expert.name.trim())){ errors.push({msg: 'Invalid value', param:'name'})}
    if(!nameRegexp2.test(expert.surname.trim())) { errors.push({msg: 'Invalid value', param:'surname'})}
    if(!emailRegexp.test(expert.email.trim())){ errors.push({msg: 'Invalid value', param:'email'})}
    if(!checkYear(expert.employedsince, 1975, 2021)){ errors.push({msg: 'Invalid value', param:'employedsince'})}
    if(!checkYear(expert.expertsince, 1975, 2021)){ errors.push({msg: 'Invalid value', param:'expertsince'})}

    
    if(errors.length == 0){
        let string = 
        `UPDATE experts
        SET name = '${expert.name.trim()}',
            surname = '${expert.surname.trim()}',
            email = '${expert.email.trim()}',
            employedsince = ${expert.employedsince},
            expertsince = ${expert.expertsince}
        WHERE id = ${id};`;
        try{
            await db.query(string);
            res.redirect('../../' + id)
        } catch (err) {
            res.render('../views/errors', {
                title: "Error Edit Expert",
                linkActive: 'order',
                errors: 'none',
                errDB: err.message,
                itemID: id
            });
        }
    } else {
        res.render('../views/errors', {
            title: "Edit Expert",
            linkActive: '',
            errors: errors,
            errDB: undefined,
            itemID: id
        });
    }
});


//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




module.exports = router;