// potrebno napisati
var express = require('express');
var router = express.Router();
const db = require('../db');

// view home
//      model : {title : 'Home'}

let getCategories = async function() {
    return (await db.query('Select id, name from categories order by id')).rows;
}

let getInventory = async function() {
    return (await db.query('select id, name, imageurl, categoryId from inventory order by id')).rows;
}

router.get('/', async function(req, res, next) {
    res.render('../views/order', {
        title: 'Order',
        linkActive: 'order',
        categories: await getCategories(),
        inventory: await getInventory()
    })
});

module.exports = router;