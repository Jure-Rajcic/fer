// potrebno napisati
const db = require("../db"); //dodaj bazu podataka
var express = require("express");
var router = express.Router();


router.get("/", async function (req, res, next) {
  res.render("partners", {
    linkActive: "partners",
    title: "Partners",
    partners: (await db.query("SELECT * FROM partners")).rows
  });
});

router.get('/create-partner', async function (req, res, next) { // pre sjebano 
  let id = parseInt(req.query.item);
  var item = (await db.query("select * from inventory where id = $1", [id])).rows[0]
  if (!item) res.status(404).send("The item you asked for does not exist!")
  else {
      res.render('create-partner', {
          title: 'Create Partner',
          linkActive: 'partners',
          item: item,
          selectData: {
              id: 'id',
              name: 'id',
              list: (await db.query('select id as value, name from inventory order by id asc')).rows
          },
          itemID: id
      })
  }
})


const emailRegexp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
const nameRegexp = /^.{2,25}$/
const checkYear = function (s, y_min, y_max) { return parseInt(s) >= y_min && parseInt(s) <= y_max; }

router.post("/create-partner", async function (req, res, next) {
  //console.log(req.body);
  //console.log(req.params)

  let partner = req.body;
  let errors = [];
  console.log(partner);

  if (!nameRegexp.test(partner.name.trim())) { errors.push({ msg: 'Invalid value', param: 'name' }) }
  if (!nameRegexp.test(partner.owner_name.trim())) { errors.push({ msg: 'Invalid value', param: 'owner_name' }) }
  if (!nameRegexp.test(partner.owner_surname.trim())) { errors.push({ msg: 'Invalid value', param: 'owner_surname' }) }
  if (!emailRegexp.test(partner.email.trim())) { errors.push({ msg: 'Invalid value', param: 'email' }) }
  if (!checkYear(partner.partnersince, 1925, 2022)) { errors.push({ msg: 'Invalid value', param: 'partner_since' }) }

  if (errors.length == 0) {
    let values = `'${partner.name.trim()}', '${partner.owner_name.trim()}',  '${partner.owner_surname.trim()}', '${partner.email.trim()}', ${parseInt(partner.partnersince)}, ${partner.id}`;
    let string = `insert into partners (name, owner_name, owner_surname, email, partnersince, partnerfor) values(${values});`;
    try {
      await db.query(string);
      res.redirect(('../../item/' + partner.id))
    } catch (err) {
      res.render('../views/errors', {
        title: "Error Create Partner",
        linkActive: 'partners',
        errors: 'none',
        errDB: err.message,
        itemID: partner.id
      });
    }
  } else {
    res.render('../views/errors', {
      title: "Error Create Partner",
      linkActive: '',
      errors: errors,
      errDB: undefined,
      itemID: partner.id
    });
  }
});

module.exports = router;
