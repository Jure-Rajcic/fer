package hr.fer.oprpp1.custom.collections;

public interface Tester<T> {
    public abstract boolean test(T obj);
    
}
