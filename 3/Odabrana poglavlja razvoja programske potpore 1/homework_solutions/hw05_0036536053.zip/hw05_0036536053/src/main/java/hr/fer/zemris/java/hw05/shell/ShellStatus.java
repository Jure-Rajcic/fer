package hr.fer.zemris.java.hw05.shell;

/**
 * enum ShellStatus represents state of a shell
 * 
 * @author Jure Rajcic
 *
 */
public enum ShellStatus {
	CONTINUE, TERMINATE;
}
