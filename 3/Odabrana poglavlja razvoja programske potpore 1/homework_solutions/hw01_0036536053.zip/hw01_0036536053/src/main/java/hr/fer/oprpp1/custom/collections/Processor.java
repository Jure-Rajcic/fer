package hr.fer.oprpp1.custom.collections;

public class Processor {
    /**
     * Processor class is a model of an object capable of performing some 
     * operation on the passed @param value using process method
     */
    public void process(Object value) {}    
}
