package hr.fer.oprpp1.hw08.jnotepadpp.actions;

public enum CaseActionType {
    TO_LOWER_CASE, TO_UPPER_CASE, INVERT_CASE
}
