package hr.fer.oprpp1.hw08.jnotepadpp.actions;

public enum SortingActionType {

    ASCENDING, DESCENDING    
}
