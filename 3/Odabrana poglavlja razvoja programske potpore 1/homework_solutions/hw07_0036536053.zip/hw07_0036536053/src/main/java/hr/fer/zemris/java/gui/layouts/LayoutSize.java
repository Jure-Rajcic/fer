package hr.fer.zemris.java.gui.layouts;
/**
 * enum  LayoutSize serves for strategy pattern in CalcLayout class
 */
public enum LayoutSize {
    MINIMUM, PREFERED, MAXIMUM;
    
}
