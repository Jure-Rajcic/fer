package hr.fer.oprpp1.hw02.prob1;

public enum TokenType { // zapakirao sam u zip P2S02 prvotnu implementaciju koja se oslanja na ModID 
    START, WORD, NUMBER, WHITESPACE, BACKSLASH, SYMBOL, EOF;
}
