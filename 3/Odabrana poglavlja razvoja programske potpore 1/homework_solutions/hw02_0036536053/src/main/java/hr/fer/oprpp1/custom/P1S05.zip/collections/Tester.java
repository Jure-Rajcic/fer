package hr.fer.oprpp1.custom.collections;

public interface Tester {
    public abstract boolean test(Object obj);
    
}
