package hr.fer.oprpp1.hw02.prob1;

public enum TokenType {
    EOF, WORD, NUMBER, SYMBOL;
    
}
