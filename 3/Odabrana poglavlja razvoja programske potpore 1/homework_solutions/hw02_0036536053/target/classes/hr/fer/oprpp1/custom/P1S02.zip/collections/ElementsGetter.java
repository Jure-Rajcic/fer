package hr.fer.oprpp1.custom.collections;

public class ElementsGetter {
    /**
     * @return true if user didn't't read all of collection elements
     */
    public boolean  hasNextElement() {return false;}

    /**
     * reads and @return referenc on next Object in collection
     */
    public Object getNextElement() {
        return null;
    }
}
