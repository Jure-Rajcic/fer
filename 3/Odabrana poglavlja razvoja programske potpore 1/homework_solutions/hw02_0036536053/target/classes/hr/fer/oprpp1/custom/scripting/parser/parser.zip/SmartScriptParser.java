package hr.fer.oprpp1.custom.scripting.parser;

import hr.fer.oprpp1.custom.scripting.lexer.SmartScriptLexer;
import hr.fer.oprpp1.custom.scripting.lexer.SmartScriptToken;
import hr.fer.oprpp1.custom.scripting.lexer.SmartscriptTokenType;
import hr.fer.oprpp1.custom.scripting.nodes.DocumentNode;
import hr.fer.oprpp1.custom.scripting.nodes.Node;

public class SmartScriptParser {
    private SmartScriptLexer lexer;
    private Node node;

    public SmartScriptParser(String doc) {
        this.lexer = new SmartScriptLexer(doc);
        this.node = new Node();
    }

    public void parse() {
        SmartScriptToken t = lexer.nextToken();
        while (t.getType() != SmartscriptTokenType.EOF) {
            System.out.println(t);
            t = lexer.nextToken();
            while (t == null)
                t = lexer.nextToken();
        }
        System.out.println("EOF");
    }

}
