package hr.fer.oprpp1.hw02.prob1.utils;

import hr.fer.oprpp1.hw02.prob1.LexerException;
import hr.fer.oprpp1.hw02.prob1.LexerState;
import hr.fer.oprpp1.hw02.prob1.Token;
import hr.fer.oprpp1.hw02.prob1.TokenType;
import hr.fer.oprpp1.hw02.prob1.demo.ObjectStack;

public class LexerMode {
    private ModID id;
    private char c;
    private Token token;
    private LexerState state;

    public LexerMode(char c, LexerState state) {
        this(c, null, state);
    }

    private LexerMode(char c, ModID id, LexerState state) {
        this.c = c;
        if (id == null)
            id = modeIdentificator(c);
        this.state = state;
        if (this.state == LexerState.EXTENDED) {
            id = switch (id) {
                case DIGIT, BACKSLASH -> ModID.LETTER;
                default -> id;
            };
        }
        this.id = id;
        this.token = null;
    }

    /**
     * @return ModID for @param c
     *         ModID is used to distinguish Lexer behaviour in different situations
     *         depending on context
     */
    private ModID modeIdentificator(char c) {
        if (c == '\0')
            return ModID.START;
        if (c == '\\')
            return ModID.BACKSLASH;
        if (c - '0' >= 0 && c - '0' <= 9)
            return ModID.DIGIT;
        if (Character.isLetter(c))
            return ModID.LETTER;
        return switch (c) {
            case ' ', '\r', '\t', '\n' -> ModID.WHITESPACE;
            default -> ModID.SYMBOL;
        };
    }

    /**
     * @param stack represents memory storage for Lexer
     * @param lm    represents new behaviour for Lexer, depending on content on
     *              stack Lexer makes choices dynamicly
     */
    public void updateMode(ObjectStack stack, LexerMode lm) {
        ModID nextId = lm.id;
        switch (this.id) {
            case START:
                stack.push(lm);
                return;
            case BACKSLASH:
                if (nextId == ModID.BACKSLASH) {
                    stack.pop();
                    stack.push(new LexerMode('\\', ModID.LETTER, this.state));
                } else if (nextId == ModID.DIGIT) {
                    stack.pop();
                    stack.push(new LexerMode(lm.c, ModID.LETTER, this.state));
                } else {
                    throw new LexerException();
                }

                return;
            case DIGIT:
                if (nextId == ModID.BACKSLASH || nextId == ModID.DIGIT) {
                    stack.push(lm);
                } else {
                    LexerMode curr = (LexerMode) stack.pop();
                    String sum = "";
                    while (curr.id == ModID.DIGIT) {
                        sum = curr.c + sum;
                        curr = (LexerMode) stack.pop();
                    }
                    stack.push(curr);
                    if (sum.length() > 15)
                        throw new LexerException();
                    token = new Token(TokenType.NUMBER, Long.parseLong(sum));
                }
                return;
            case LETTER:
                System.out.println("printing from processLetter:" + lm);
                if (nextId == ModID.BACKSLASH || nextId == ModID.LETTER) {
                    stack.push(lm);
                } else {
                    LexerMode curr = (LexerMode) stack.pop();
                    String word = "";
                    while (curr.id == ModID.LETTER) {
                        word = curr.c + word;
                        curr = (LexerMode) stack.pop();
                    }
                    stack.push(curr);
                    token = new Token(TokenType.WORD, word);
                }
                return;
            case WHITESPACE:
                if (nextId != ModID.WHITESPACE) {
                    LexerMode curr = (LexerMode) stack.pop();
                    String word = "";
                    while (curr.id == ModID.WHITESPACE) {
                        word = curr.c + word;
                        curr = (LexerMode) stack.pop();
                    }
                    stack.push(curr);
                }
                stack.push(lm);
                return;
            case SYMBOL:
                LexerMode curr = (LexerMode) stack.pop();
                token = new Token(TokenType.SYMBOL, curr.c);
                return;
            default:
                throw new LexerException("invalid lexer mode");
        }
    }

    /**
     * when Lexer changes behaviours token can be genereted or in process of
     * generating
     * 
     * @return true only if token is generated
     */
    public boolean isTokenReady() {
        return token != null;
    }

    /**
     * @returns generated token
     */
    public Token getToken() {
        return token;
    }

    @Override
    public String toString() {
        return "c:" + c + " id:" + id + " token:" + token;
    }

}
