package hr.fer.oprpp1.hw02.prob1.utils;

public enum ModID {
    START, WHITESPACE, BACKSLASH, LETTER, DIGIT, SYMBOL;
}
