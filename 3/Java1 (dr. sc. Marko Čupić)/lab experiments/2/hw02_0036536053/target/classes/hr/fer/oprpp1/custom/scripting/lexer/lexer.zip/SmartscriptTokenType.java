package hr.fer.oprpp1.custom.scripting.lexer;

public enum SmartscriptTokenType { // zapakirao sam u zip P2S02 prvotnu implementaciju koja se oslanja na ModID 
    START, WHITESPACE, WORD, NUMBER, LONG, DOUBLE, SYMBOL, KEYWORD, FUNCTION, BACKSLASH, EOF, OPERATOR, STRING;
}
