package hr.fer.oprpp1.custom.scripting.lexer;

public class SmartScriptLexerException extends RuntimeException {

    public SmartScriptLexerException() {
    }

    public SmartScriptLexerException(String message) {
        super(message);
    }

    public SmartScriptLexerException(Throwable cause) {
        super(cause);
    }

    public SmartScriptLexerException(String message, Throwable cause) {
        super(message, cause);
    }

}
