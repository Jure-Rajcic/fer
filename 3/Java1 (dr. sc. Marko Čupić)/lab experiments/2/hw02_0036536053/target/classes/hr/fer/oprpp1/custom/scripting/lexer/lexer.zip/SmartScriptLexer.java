package hr.fer.oprpp1.custom.scripting.lexer;

import hr.fer.oprpp1.custom.scripting.demo.ObjectStack;

public class SmartScriptLexer {
    private char[] data; // ulazni tekst
    private SmartScriptToken token; // trenutni token
    private int currentIndex; // indeks prvog neobrađenog znaka
    // konstruktor prima ulazni tekst koji se tokenizira
    private ObjectStack stack; // lexerov memoriaj
    private SmartScriptLexerMode lm; // trenutni mod u kojem se lexer nalazi
    // private SmartScriptLexerState state;
    private char sign;

    /**
     * creates Lexer object
     * 
     * @param text represents input theat Lexer needs to turn in tokens
     * @thROWS NullPointerException if text is null
     */
    public SmartScriptLexer(String text) {
        if (text == null)
            throw new NullPointerException();
        this.data = (" " + text + " ").toCharArray();
        this.currentIndex = 0;
        this.stack = new ObjectStack();
        // this.state = SmartScriptLexerState.BASIC;
        // this.lm = new SmartScriptLexerMode('\0', this.state);
        this.lm = new SmartScriptLexerMode('\0');
        stack.push(lm);
        this.sign = '+';
    }

    // generira i vraća sljedeći token
    // baca LexerException ako dođe do pogreške
    public SmartScriptToken nextToken() {
        if (token != null && token.getType() == SmartscriptTokenType.EOF)
            throw new SmartScriptLexerException();
        while (currentIndex < data.length) {
            char c = data[currentIndex];
            SmartScriptLexerMode curr = lm;
            lm.updateMode(stack, new SmartScriptLexerMode(c));
            lm = (SmartScriptLexerMode) stack.peek();
            if (curr.isTokenReady()) {
                SmartScriptToken currToken = curr.getToken();
                SmartscriptTokenType tokenType = currToken.getType();
                Object value = currToken.getValue();
                if (tokenType == SmartscriptTokenType.WORD) {
                    if (((String) value).toCharArray()[0] == '@')
                        currToken = new SmartScriptToken(SmartscriptTokenType.FUNCTION, ((String) value));
                    if (((String) value).toUpperCase().equals("FOR"))
                        currToken = new SmartScriptToken(SmartscriptTokenType.KEYWORD, "FOR");
                }
                if (tokenType == SmartscriptTokenType.SYMBOL) {
                    if (((Character) value).equals('='))
                        currToken = new SmartScriptToken(SmartscriptTokenType.KEYWORD, "=");
                    if (((Character) value).equals('+') || ((Character) value).equals('-')) {
                        if (Character.isDigit(data[currentIndex])) {
                            this.sign = (Character) value;
                            return null;
                        }
                    }
                    currToken = switch (((Character) value)) {
                        case '+', '-', '*', '/', '^' -> new SmartScriptToken(SmartscriptTokenType.OPERATOR, value);
                        default -> currToken;
                    };
                }

                if (tokenType == SmartscriptTokenType.LONG || tokenType == SmartscriptTokenType.DOUBLE) {
                    int factor = this.sign == '-' ? -1 : 1;
                    currToken = switch (tokenType) {
                        case LONG ->
                            new SmartScriptToken(SmartscriptTokenType.LONG, factor * (Long) currToken.getValue());
                        case DOUBLE ->
                            new SmartScriptToken(SmartscriptTokenType.DOUBLE, factor * (Double) currToken.getValue());
                        default -> throw new SmartScriptLexerException("I was expecting number");
                    };
                    this.sign = '+';
                }
                if (tokenType == SmartscriptTokenType.STRING || tokenType == SmartscriptTokenType.BACKSLASH) {
                    currentIndex++;
                }
                this.token = currToken;
                break;
            }
            currentIndex++;
        }
        lm = (SmartScriptLexerMode) stack.peek();

        if (this.currentIndex == data.length) {
            if (token == null || token.getType() != SmartscriptTokenType.EOF)
                this.token = new SmartScriptToken(SmartscriptTokenType.EOF, null);
        }
        return getToken();
    }

    // vraća zadnji generirani token; može se pozivati
    // više puta; ne pokreće generiranje sljedećeg tokena
    public SmartScriptToken getToken() {
        return this.token;
    }

    // public void setState(SmartScriptLexerState state) {
    //     if (state == null)
    //         throw new NullPointerException();
    //     this.state = state;
    // }

}