package hr.fer.oprpp1.custom.scripting.lexer;

import hr.fer.oprpp1.custom.scripting.demo.ObjectStack;

public class SmartScriptLexerMode {
    private SmartscriptTokenType id;
    private char c;
    private SmartScriptToken token;
    // private SmartScriptLexerState state;

    public SmartScriptLexerMode(char c) {
        // public SmartScriptLexerMode(char c, SmartScriptLexerState state) {
            this(c, null);
    }

    private SmartScriptLexerMode(char c, SmartscriptTokenType id) {
        // private SmartScriptLexerMode(char c, SmartscriptTokenType id, SmartScriptLexerState state) {
            this.c = c;
        if (id == null)
            id = modeIdentificator(c);
        // this.state = state;

        // if (this.state == SmartScriptLexerState.STRING) {
        //     id = switch (id) {
        //         case STRING -> SmartscriptTokenType.START;
        //         default -> id;
        //     };
        // }
        this.id = id;
        this.token = null;
    }

    /**
     * @return TokenType for @param c
     *         TokenType is used to distinguish Lexer behaviour in different
     *         situations
     *         depending on context
     */
    private SmartscriptTokenType modeIdentificator(char c) {
        if (c == '\0')
            return SmartscriptTokenType.START;
        if (c == '\\')
            return SmartscriptTokenType.BACKSLASH;
        if ((c - '0' >= 0 && c - '0' <= 9) || (c == '.'))
            return SmartscriptTokenType.NUMBER;
        if (Character.isLetter(c) || c == '@')
            return SmartscriptTokenType.WORD;
        if (c == '"')
            return SmartscriptTokenType.STRING;
        return switch (c) {
            case ' ', '\r', '\t', '\n' -> SmartscriptTokenType.WHITESPACE;
            default -> SmartscriptTokenType.SYMBOL;
        };
    }

    /**
     * @param stack represents memory storage for Lexer
     * @param lm    represents new behaviour for Lexer, depending on content on
     *              stack Lexer makes choices dynamicly
     */
    public void updateMode(ObjectStack stack, SmartScriptLexerMode lm) {
        SmartscriptTokenType nextId = lm.id;
        switch (this.id) {
            case START:
                stack.push(lm);
                return;
            case BACKSLASH:
                if (nextId == SmartscriptTokenType.SYMBOL && lm.c == '{'){
                    stack.pop();
                    token = new SmartScriptToken(SmartscriptTokenType.SYMBOL, '\\');
                } 
                // if (nextId == SmartscriptTokenType.BACKSLASH) {
                //     stack.pop();
                //     token = new SmartScriptToken(SmartscriptTokenType.BACKSLASH, '\\');
                //     // stack.push(new SmartScriptLexerMode('\\', SmartscriptTokenType.WORD));
                // } 
                // else if (nextId == SmartscriptTokenType.NUMBER) {
                //     stack.pop();
                //     // stack.push(new SmartScriptLexerMode(lm.c, SmartscriptTokenType.WORD, this.state));
                //     stack.push(new SmartScriptLexerMode(lm.c, SmartscriptTokenType.WORD));
                // } else {
                //     throw new SmartScriptLexerException();
                // }

                return;
            case NUMBER:
                if (nextId == SmartscriptTokenType.BACKSLASH || nextId == SmartscriptTokenType.NUMBER) {
                    stack.push(lm);
                } else {
                    SmartScriptLexerMode curr = (SmartScriptLexerMode) stack.pop();
                    String number = "";
                    while (curr.id == SmartscriptTokenType.NUMBER) {
                        number = curr.c + number;
                        curr = (SmartScriptLexerMode) stack.pop();
                    }
                    stack.push(curr);
                    if (number.length() > 15)
                        throw new SmartScriptLexerException();
                    if (number.contains("."))
                        token = new SmartScriptToken(SmartscriptTokenType.DOUBLE, Double.parseDouble(number));
                    else
                        token = new SmartScriptToken(SmartscriptTokenType.LONG, Long.parseLong(number));
                }
                return;
            case WORD:
                if (nextId == SmartscriptTokenType.BACKSLASH || nextId == SmartscriptTokenType.WORD) {
                    stack.push(lm);
                } else {
                    SmartScriptLexerMode curr = (SmartScriptLexerMode) stack.pop();
                    String word = "";
                    while (curr.id == SmartscriptTokenType.WORD) {
                        word = curr.c + word;
                        curr = (SmartScriptLexerMode) stack.pop();
                    }
                    stack.push(curr);
                    token = new SmartScriptToken(SmartscriptTokenType.WORD, word);
                }
                return;
            case WHITESPACE:
                if (nextId != SmartscriptTokenType.WHITESPACE) {
                    SmartScriptLexerMode curr = (SmartScriptLexerMode) stack.pop();
                    String word = "";
                    while (curr.id == SmartscriptTokenType.WHITESPACE) {
                        word = curr.c + word;
                        curr = (SmartScriptLexerMode) stack.pop();
                    }
                    stack.push(curr);
                }
                stack.push(lm);
                return;
            case SYMBOL:
                // if (nextId != SmartscriptTokenType.SYMBOL && lm.c == '$') {
                //     SmartScriptLexerMode curr = (SmartScriptLexerMode) stack.pop();
                //     if (curr.c == '{'){
                //         curr = (SmartScriptLexerMode) stack.pop();

                //     }

                //     return;
                // }
                SmartScriptLexerMode curr = (SmartScriptLexerMode) stack.pop();
                token = new SmartScriptToken(SmartscriptTokenType.SYMBOL, curr.c);
                return;
            case STRING:
                stack.push(new SmartScriptLexerMode(lm.c, SmartscriptTokenType.STRING));
                if (nextId == SmartscriptTokenType.STRING) {
                    curr = (SmartScriptLexerMode) stack.pop();
                    String string = "";
                    while (curr.id == SmartscriptTokenType.STRING) {
                        string = curr.c + string;
                        curr = (SmartScriptLexerMode) stack.pop();
                    }
                    stack.push(curr);
                    token = new SmartScriptToken(SmartscriptTokenType.STRING, string);
                }
                return;
            default:
                throw new SmartScriptLexerException("invalid lexer mode");
        }
    }

    /**
     * when Lexer changes behaviours token can be genereted or in process of
     * generating
     * 
     * @return true only if token is generated
     */
    public boolean isTokenReady() {
        return token != null;
    }

    /**
     * @returns generated token
     */
    public SmartScriptToken getToken() {
        return token;
    }

    @Override
    public String toString() {
        return "c:" + c + " id:" + id + " token:" + token;
    }

}
