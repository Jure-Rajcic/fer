package hr.fer.oprpp1.custom.scripting.lexer;

public class SmartScriptToken {
    private SmartscriptTokenType type;
    private Object value;

    public SmartScriptToken(SmartscriptTokenType type, Object value) {
        this.type = type;
        this.value = value;
    }

    public Object getValue() {
        return this.value;
    }

    public SmartscriptTokenType getType() {
        return this.type;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof SmartScriptToken))
            return false;
        SmartScriptToken t = (SmartScriptToken) o;
        if(value == null)  return type == t.type && value == t.value;
        return type == t.type && value.equals(t.value);
    }

    @Override
    public String toString() {
        return "type " + type + " value " + value;
    }
}
