public class CalculatedFuzzySet implements IFuzzySet {
    
    private IDomain domain;
    private IlntUnaryFunction function;
    CalculatedFuzzySet(IDomain domain, IlntUnaryFunction function) {
        this.domain = domain;
        this.function = function;
    }

    @Override
    public IDomain getDomain() {
        return domain;
    }

    @Override
    public double getValueAt(DomainElement element) {
        return function.valueAt(domain.indexOfElement(element));
    }


}
