public class Operations {
    
    public static IFuzzySet unaryOperation(IFuzzySet set, IUnaryFunction function) {
        MutableFuzzySet result = new MutableFuzzySet(set.getDomain());
        for (DomainElement element : set.getDomain()) {
            double value = set.getValueAt(element);
            result.set(element, function.valueAt(value));
        }
        return result;
    }

    public static IFuzzySet binaryOperation(IFuzzySet set1, IFuzzySet set2, IBinaryFunction function) {
        MutableFuzzySet result = new MutableFuzzySet(set1.getDomain());
        for (DomainElement element : set1.getDomain()) {
            double value1 = set1.getValueAt(element);
            double value2 = set2.getValueAt(element);
            result.set(element, function.valueAt(value1, value2));
        }
        return result;
    }

    public static IUnaryFunction zadehNot() {
        return (double x) -> 1 - x;
    }

    public static IBinaryFunction zadehAnd() {
        return (double x, double y) -> Math.min(x, y);
    }

    public static IBinaryFunction zadehOr() {
        return (double x, double y) -> Math.max(x, y);
    }

    public static IBinaryFunction hamacherTNorm(double v) {
        return (double a, double b) -> (a * b) / (v + (1 - v) * (a + b - a * b));
    }

    public static IBinaryFunction hamacherSNorm(double v) {
        return (double a, double b) -> (a + b - (2 - v) * a * b) / (1 - (1 - v) * a * b);
    }

}
