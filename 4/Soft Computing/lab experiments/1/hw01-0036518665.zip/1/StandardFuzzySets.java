public class StandardFuzzySets {

    public static IlntUnaryFunction IFunction(int alpha, int beta) {
        return (index) -> {
            if (index < alpha) return 1;
            else if (alpha <= index && index < beta) return 1.0 * (beta - index) / (beta - alpha);
            else return 0;
        };
    }

   

    public static IlntUnaryFunction gamaFunction(int alpha, int beta) {
        return (index) -> {
            if (index < alpha) return 0;
            else if (alpha <= index && index < beta) return 1.0 * (index - alpha) / (beta - alpha);
            else return 1;
        };
    }

    public static IlntUnaryFunction lambdaFunction(int alpha, int beta, int gama) {
        return (index) -> {
            if (index < alpha) return 0;
            else if (alpha <= index && index < beta) return 1.0 * (index - alpha) / (beta - alpha);
            else if (beta <= index && index < gama) return 1.0 * (gama - index) / (gama - beta);
            else return 0;
        };

    }

}
