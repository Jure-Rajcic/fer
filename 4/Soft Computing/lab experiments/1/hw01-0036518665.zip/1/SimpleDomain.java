import java.util.Iterator;
import java.util.NoSuchElementException;

public class SimpleDomain extends Domain {

    private int first;
    private int last;

    public SimpleDomain(int first, int last) {
        this.first = first;
        this.last = last;
    }

    @Override
    public int getCardinality() {
        return last - first;
    }

    @Override
    public IDomain getComponent(int index) {
        if (index < getNumberOfComponents()) return this;
        return null;
    }

    @Override
    public int getNumberOfComponents() {
        return 1;
    }

    @Override
    public Iterator<DomainElement> iterator() {
        return new SimpleDomainIterator();
    }

    private class SimpleDomainIterator implements Iterator<DomainElement> {

        private int current;

        public SimpleDomainIterator() {
            current = first;
        }

        @Override
        public boolean hasNext() {
            return current < last;
        }

        @Override
        public DomainElement next() {
            if (!hasNext()) throw new NoSuchElementException();
            int[] values = {current};
            current++;
            return new DomainElement(values);
        }

    }

    public int getFirst() {
        return first;
    }

    public int getLast() {
        return last;
    }

    @Override
    public String toString() {
        return "[" + first + "," + last + "]";
    }
    
}
