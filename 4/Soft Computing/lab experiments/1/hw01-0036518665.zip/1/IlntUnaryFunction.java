@FunctionalInterface
public interface IlntUnaryFunction {
    public double valueAt(int index);
}
