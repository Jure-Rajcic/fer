
public class Debug {

    public static void print(IDomain domain, String headingText) {
        if (headingText != null) {
            System.out.println(headingText);
        }
        for (DomainElement e : domain) {
            System.out.println("Element domene: " + e);
        }
        System.out.println("Kardinalitet domene je: " + domain.getCardinality());
        System.out.println();
    }

    public static void print(IFuzzySet set1, String headingText) {
        if (headingText != null) {
            System.out.println(headingText);
        }
        for (DomainElement e : set1.getDomain()) {
            System.out.println("d" + e + "=" + String.format("%.2f", set1.getValueAt(e)) );
        }
        System.out.println();
    }

}
