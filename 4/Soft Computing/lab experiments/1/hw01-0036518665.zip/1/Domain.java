
public abstract class Domain implements IDomain {

    public static IDomain intRange(int first, int last) {
        return new SimpleDomain(first, last);
    }

    public static IDomain combine(IDomain... ids) {
        return new CompositeDomain(ids);
    }

    @Override
    public int indexOfElement(DomainElement element) {
        int index = 0;
        for (DomainElement e : this) {
            if (e.equals(element))
                return index;
            index++;
        }
        return -1;
    }

    @Override
    public DomainElement elementForIndex(int index) {
        int i = 0;
        for (DomainElement e : this) {
            if (i == index) {
                return e;
            }
            i++;
        }
        throw new IndexOutOfBoundsException();
    }

}
