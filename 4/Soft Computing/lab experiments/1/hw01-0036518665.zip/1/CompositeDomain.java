import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Queue;

public class CompositeDomain extends Domain {

    private IDomain[] components;

    CompositeDomain(IDomain... components) {
        this.components = components;
    }

    @Override
    public Iterator<DomainElement> iterator() {
        return new CompositeDomainIterator();
    }

    private class CompositeDomainIterator implements Iterator<DomainElement> {

        private Iterator<DomainElement>[] iterators;
        private DomainElement[] domainElements;
        private int[] domainElementComponentValueIndexes;

        @SuppressWarnings("unchecked")
        CompositeDomainIterator() {
            iterators = new Iterator[getNumberOfComponents()];
            for (int i = 0; i < iterators.length; i++) iterators[i] = getComponent(i).iterator();

            domainElements = new DomainElement[getNumberOfComponents()];
            for (int i = 0; i < domainElements.length; i++) domainElements[i] = iterators[i].next();

            domainElementComponentValueIndexes = new int[getNumberOfComponents()];
            domainElementComponentValueIndexes[domainElementComponentValueIndexes.length - 1] = -1;
        }

        @Override
        public boolean hasNext() {
            for (Iterator<DomainElement> iterator : iterators) {
                if (iterator.hasNext()) return true;
            }
            return false;
        }

        @Override
        public DomainElement next() {
            if (!hasNext()) throw new NoSuchElementException();

            int[] values = new int[getNumberOfComponents()];
            updateIndexes(getNumberOfComponents() - 1);


            for (int i = 0; i < values.length; i++) {
                DomainElement de = domainElements[i];
                int value = de.getComponentValue(domainElementComponentValueIndexes[i]);
                values[i] = value;
            }

            return new DomainElement(values);
           
        }

        private void updateIndexes(int index) {

            if (index < 0) return;

            int value = domainElementComponentValueIndexes[index]; 
            DomainElement de = domainElements[index];
            Iterator<DomainElement> it = iterators[index];

            value++;
            if (value < de.getNumberOfComponents()) {
                domainElementComponentValueIndexes[index] = value;
                return;
            }
            
            if (it.hasNext()) {
                de = it.next();
                domainElements[index] = de;
                domainElementComponentValueIndexes[index] = 0;
                return;
            }


            iterators[index] = getComponent(index).iterator();
            it = iterators[index];	
            de = it.next();
            domainElements[index] = de;
            domainElementComponentValueIndexes[index] = 0;
            updateIndexes(index - 1);
        }

       

    }

    @Override
    public int getCardinality() {
        int cardinality = 1;
        for (IDomain component : components) {
            cardinality *= component.getCardinality();
        }
        return cardinality;
    }

    @Override
    public IDomain getComponent(int index) {
        Queue<IDomain> queue = new LinkedList<>();
        queue.add(this);

        while (!queue.isEmpty()) {
            IDomain id = queue.remove();
            if (id instanceof CompositeDomain) {
                CompositeDomain cd = (CompositeDomain) id;
                for (IDomain component : cd.components) {
                    queue.add(component);
                }
            } else {
                if (index == 0) return id;
                index--;
            }
        }
        return null;
        
    }

    


    

    @Override
    public int getNumberOfComponents() {
        int numberOfComponents = 0;
        for (IDomain component : components) {
            numberOfComponents += component.getNumberOfComponents();
        }
        return numberOfComponents;
    }

}
