
public class DomainElement {

    private int[] values;

    public DomainElement(int[] values) {
        this.values = values;
    }


    public int getNumberOfComponents() {
        return values.length;
    }

    public int getComponentValue(int index) {
        return values[index];
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + java.util.Arrays.hashCode(this.values);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) return false;
        if (obj == this) return true;
        if (obj.hashCode() != this.hashCode()) return false;
        if (!(obj instanceof DomainElement)) return false;
        DomainElement de = (DomainElement) obj;
        if (de.getNumberOfComponents() != this.getNumberOfComponents()) return false;
        for (int i = 0; i < this.getNumberOfComponents(); i++) {
            if (de.getComponentValue(i) != this.getComponentValue(i)) return false;
        }
        return true;        
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        for (int i = 0; i < values.length - 1; i++) {
            sb.append(values[i]);
            sb.append(",");
        }
        sb.append(values[values.length - 1]);
        sb.append(")");
        
        return sb.toString();
        
    }


    public static DomainElement of(int... values) {
        DomainElement de = new DomainElement(values);
        return de;
    }

}
