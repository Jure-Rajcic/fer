import java.util.LinkedHashSet;
import java.util.Set;

public class Relations {

    public static boolean isSymmetric(IFuzzySet set) {
        IDomain domain = set.getDomain();
        if (domain.getNumberOfComponents() != 2)
            throw new IllegalArgumentException("Domain must have two components");

        for (DomainElement de : domain) {
            DomainElement deReversed = DomainElement.of(de.getComponentValue(1), de.getComponentValue(0));
            if (set.getValueAt(de) != set.getValueAt(deReversed))
                return false;
        }
        return true;

    }

    public static boolean isReflexive(IFuzzySet set) {
        IDomain domain = set.getDomain();
        if (domain.getNumberOfComponents() != 2)
            throw new IllegalArgumentException("Domain must have two components");

        for (DomainElement de : domain) {
            if (de.getComponentValue(0) != de.getComponentValue(1))
                continue;
            if (set.getValueAt(de) != 1.0)
                return false;
        }
        return true;
    }

    public static boolean isMaxMinTransitive(IFuzzySet set) {
        IDomain domain = set.getDomain();
        if (domain.getNumberOfComponents() != 2)
            throw new IllegalArgumentException("Domain must have two components");

        Set<Integer> lhs = new LinkedHashSet<>();
        for (DomainElement de : domain) {
            lhs.add(de.getComponentValue(0));
            lhs.add(de.getComponentValue(1));
        }
        Integer[] array = lhs.toArray(new Integer[0]);

        for (int i = 0; i < lhs.size() - 2; i++) {
            for (int j = i + 1; j < lhs.size() - 1; j++) {
                for (int k = j + 1; k < lhs.size(); k++) {
                    DomainElement xz = DomainElement.of(array[i], array[k]);
                    DomainElement xy = DomainElement.of(array[i], array[j]);
                    DomainElement yz = DomainElement.of(array[j], array[k]);
                    if (set.getValueAt(xz) < Math.min(set.getValueAt(xy), set.getValueAt(yz))) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    public static boolean isFuzzyEquivalence(IFuzzySet set) {
        return isReflexive(set) && isSymmetric(set) && isMaxMinTransitive(set);
    }

    public static IFuzzySet compositionOfBinaryRelations(IFuzzySet set1, IFuzzySet set2) {
        IDomain domain1 = set1.getDomain();
        IDomain domain2 = set2.getDomain();

        if (domain1.getNumberOfComponents() != 2 || domain2.getNumberOfComponents() != 2) {
            throw new IllegalArgumentException("Both input sets must have a domain with two components.");
        }

        IDomain compositionDomain = Domain.combine(domain1.getComponent(0), domain2.getComponent(1));
        MutableFuzzySet composition = new MutableFuzzySet(compositionDomain);

        Set<Integer> lhsX = new LinkedHashSet<>();
        Set<Integer> lhsY = new LinkedHashSet<>();
        Set<Integer> lhsZ = new LinkedHashSet<>();

        for (DomainElement de : domain1) {
            lhsX.add(de.getComponentValue(0));
            lhsY.add(de.getComponentValue(1));
        }
        for (DomainElement de : domain2) {
            lhsY.add(de.getComponentValue(0));
            lhsZ.add(de.getComponentValue(1));
        }

        Integer[] arrayX = lhsX.toArray(new Integer[0]);
        Integer[] arrayY = lhsY.toArray(new Integer[0]);
        Integer[] arrayZ = lhsZ.toArray(new Integer[0]);

        for (int x : arrayX) {
            for (int z : arrayZ) {
                DomainElement xz = DomainElement.of(x, z);
                double max = 0;
                for (int y : arrayY) {
                    DomainElement xy = DomainElement.of(x, y);
                    DomainElement yz = DomainElement.of(y, z);

                    double min = Math.min(set1.getValueAt(xy), set2.getValueAt(yz));
                    max = Math.max(max, min);
                }
                composition.set(xz, max);
            }
        }
        return composition;
    }

    public static boolean isUtimesURelation(IFuzzySet set) {
        IDomain domain = set.getDomain();
        int numberOfComponents = domain.getNumberOfComponents();
        if (numberOfComponents != 2)
            return false;
        IDomain firstComponent = domain.getComponent(0);
        IDomain secondComponent = domain.getComponent(1);

        return firstComponent.equals(secondComponent);
    }

}
